using XmobiTea.ProtonNet.Server.WebApi.Controllers;
using XmobiTea.ProtonNet.Server.WebApi.Controllers.Attribute;
using XmobiTea.ProtonNetCommon;

namespace $safeprojectname$.Controllers
{
    [Route("/")]
    internal class IndexController : WebApiController
    {
        [HttpGet("")]
        private HttpResponse Index()
        {
            return this.View("Index", "_Layout", new Server.WebApi.Models.ViewData()
                .SetData("Title", "Proton WebApiServer"));
        }

    }

}
